/*=====================================
        USUARIO INFO
=====================================*/

function iniciarUsuarioInfo() {

    console.log("Vista Información Usuario cargada");

    //==========================
    // OBTENER ID Y PEDIR DATOS REALES AL SERVIDOR
    //==========================

    const usuarioId = sessionStorage.getItem("usuarioId");

    if (!usuarioId) {
        alert("No se encontró información del usuario.");
        cargarVista("usuarios");
        return;
    }

    fetch(`/api/admin/usuarios/${usuarioId}/`)
        .then(res => res.json())
        .then(data => {
            if (!data.ok) {
                alert(data.error || "No se pudo cargar la información del usuario.");
                cargarVista("usuarios");
                return;
            }
            pintarUsuario(data.usuario);
        })
        .catch(err => {
            console.error("Error al cargar usuario:", err);
            alert("Error de conexión al cargar la información del usuario.");
        });

    //==========================
    // BOTÓN REGRESAR
    //==========================

    document.getElementById("volver").addEventListener("click", () => {
        cargarVista("usuarios");
    });

    //==========================
    // BOTONES LATERALES (pestañas)
    //==========================

    const btnGeneral = document.getElementById("btnGeneral");
    const btnMedico = document.getElementById("btnMedico");
    const btnVerificacion = document.getElementById("btnVerificacion");
    const panelGeneral = document.getElementById("panelGeneral");
    const panelVerificacion = document.getElementById("panelVerificacion");

    function mostrarPanel(panelActivo) {
        [panelGeneral, panelVerificacion].forEach(panel => {
            if (panel) panel.style.display = panel === panelActivo ? "" : "none";
        });
        [btnGeneral, btnVerificacion].forEach(btn => btn && btn.classList.remove("active"));
    }

    btnGeneral.addEventListener("click", () => {
        mostrarPanel(panelGeneral);
        btnGeneral.classList.add("active");
    });

    if (btnVerificacion) {
        btnVerificacion.addEventListener("click", () => {
            mostrarPanel(panelVerificacion);
            btnVerificacion.classList.add("active");
        });
    }

    btnMedico.addEventListener("click", () => {
        cargarVista("expediente");
    });

    //==========================
    // GUARDAR (información general) -- ahora sí llama al servidor
    //==========================

    document.getElementById("formGeneral").addEventListener("submit", function (e) {
        e.preventDefault();

        const payload = {
            nombre: document.getElementById("nombre").value,
            correo: document.getElementById("correo").value,
            matricula: document.getElementById("matricula").value,
            cuatrimestre: document.getElementById("cuatrimestre").value,
            carrera: document.getElementById("carrera").value,
            rol: document.getElementById("rol").value,
            estado: document.getElementById("estado").value,
            telefono: document.getElementById("telefono").value,
        };

        const password = document.getElementById("password").value;
        if (password.trim()) {
            payload.password = password;
        }

        fetch(`/api/admin/usuarios/${usuarioId}/actualizar/`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": obtenerCSRFToken(),
            },
            body: JSON.stringify(payload),
        })
            .then(res => res.json())
            .then(data => {
                if (data.ok) {
                    alert("Información guardada correctamente.");
                    document.getElementById("password").value = "";
                    if (payload.rol === "conductor") {
                        fetch(`/api/admin/usuarios/${usuarioId}/`)
                            .then(r => r.json())
                            .then(d => d.ok && pintarUsuario(d.usuario));
                    }
                } else {
                    alert(data.error || "No se pudo guardar la información.");
                }
            })
            .catch(err => {
                console.error("Error al guardar:", err);
                alert("Error de conexión al guardar los datos.");
            });
    });

    //==========================
    // Pinta los datos reales recibidos del servidor
    //==========================

    function pintarUsuario(usuario) {
        document.getElementById("fotoUsuario").src = "/static/img/admin.png";
        document.getElementById("nombreTitulo").textContent = usuario.nombre;

        document.getElementById("nombre").value = usuario.nombre || "";
        document.getElementById("correo").value = usuario.correo || "";
        document.getElementById("matricula").value = usuario.matricula || "";
        document.getElementById("cuatrimestre").value = usuario.cuatrimestre || "";
        document.getElementById("carrera").value = usuario.carrera || "";
        document.getElementById("rol").value = usuario.rol || "";
        document.getElementById("estado").value = usuario.estado || "";
        document.getElementById("password").value = "";
        document.getElementById("telefono").value = usuario.telefono || "";

        if (btnVerificacion) {
            if (usuario.rol === "conductor") {
                btnVerificacion.style.display = "";
                pintarVerificacion(usuario);
            } else {
                btnVerificacion.style.display = "none";
                if (panelVerificacion) panelVerificacion.style.display = "none";
            }
        }
    }

    //==========================
    // Pestaña de verificación (licencia + vehículo)
    //==========================

    function pintarVerificacion(usuario) {
        const conductor = usuario.conductor;
        const vehiculo = usuario.vehiculo;

        const contenedor = document.getElementById("verificacionContenido");
        if (!contenedor) return;

        if (!conductor) {
            contenedor.innerHTML = "<p>Este conductor todavía no ha registrado su información.</p>";
            return;
        }

        const fotoFrontalHtml = conductor.foto_licencia_frontal
            ? `<a href="${conductor.foto_licencia_frontal}" target="_blank">Ver foto frontal de licencia</a>`
            : "<span>Sin foto frontal</span>";

        const fotoReversoHtml = conductor.foto_licencia_reverso
            ? `<a href="${conductor.foto_licencia_reverso}" target="_blank">Ver foto posterior de licencia</a>`
            : "<span>Sin foto posterior</span>";

        let vehiculoHtml = "<p>Este conductor todavía no ha registrado un vehículo.</p>";
        if (vehiculo) {
            const fotoVehiculoHtml = vehiculo.foto
                ? `<a href="${vehiculo.foto}" target="_blank">Ver foto del vehículo</a>`
                : "<span>Sin foto</span>";

            vehiculoHtml = `
                <div class="verificacion-bloque">
                    <h3>Vehículo</h3>
                    <p><strong>${vehiculo.marca} ${vehiculo.modelo} (${vehiculo.anio})</strong> -- Placas: ${vehiculo.placas}</p>
                    <p>Color: ${vehiculo.color} · Capacidad: ${vehiculo.capacidad}</p>
                    <p>${fotoVehiculoHtml}</p>
                    <p>Estado actual: <strong>${vehiculo.estado_display}</strong></p>
                    ${vehiculo.motivo_rechazo ? `<p>Motivo de rechazo anterior: ${vehiculo.motivo_rechazo}</p>` : ""}
                    <div class="verificacion-acciones">
                        <button type="button" class="btn-aprobar" data-tipo="vehiculo" data-id="${vehiculo.id}">Aprobar vehículo</button>
                        <button type="button" class="btn-rechazar" data-tipo="vehiculo" data-id="${vehiculo.id}">Rechazar vehículo</button>
                    </div>
                </div>
            `;
        }

        contenedor.innerHTML = `
            <div class="verificacion-bloque">
                <h3>Licencia de conducir</h3>
                <p>Número: <strong>${conductor.numero_licencia || "—"}</strong></p>
                <p>Vencimiento: ${conductor.fecha_vencimiento || "—"}</p>
                <p>${fotoFrontalHtml}</p>
                <p>${fotoReversoHtml}</p>
                <p>Estado actual: <strong>${conductor.estado_verificacion_display}</strong></p>
                ${conductor.motivo_rechazo ? `<p>Motivo de rechazo anterior: ${conductor.motivo_rechazo}</p>` : ""}
                <div class="verificacion-acciones">
                    <button type="button" class="btn-aprobar" data-tipo="conductor" data-id="${usuario.id}">Aprobar conductor</button>
                    <button type="button" class="btn-rechazar" data-tipo="conductor" data-id="${usuario.id}">Rechazar conductor</button>
                </div>
            </div>
            ${vehiculoHtml}
        `;

        contenedor.querySelectorAll(".btn-aprobar").forEach(btn => {
            btn.addEventListener("click", () => enviarDecision(btn.dataset.tipo, btn.dataset.id, "aprobado"));
        });
        contenedor.querySelectorAll(".btn-rechazar").forEach(btn => {
            btn.addEventListener("click", () => {
                const motivo = prompt("¿Por qué se rechaza? (obligatorio)");
                if (motivo && motivo.trim()) {
                    enviarDecision(btn.dataset.tipo, btn.dataset.id, "rechazado", motivo.trim());
                }
            });
        });
    }

    function enviarDecision(tipo, id, decision, motivo) {
        const url = tipo === "conductor"
            ? `/api/admin/conductores/${id}/verificar/`
            : `/api/admin/vehiculos/${id}/verificar/`;

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": obtenerCSRFToken(),
            },
            body: JSON.stringify({ decision, motivo: motivo || "" }),
        })
            .then(res => res.json())
            .then(data => {
                if (data.ok) {
                    alert(data.mensaje);
                    fetch(`/api/admin/usuarios/${usuarioId}/`)
                        .then(r => r.json())
                        .then(d => d.ok && pintarUsuario(d.usuario));
                } else {
                    alert(data.error || "No se pudo procesar la decisión.");
                }
            })
            .catch(err => {
                console.error("Error al verificar:", err);
                alert("Error de conexión al procesar la decisión.");
            });
    }
}
